# Patent Notice

## Pending Patent Applications

The following techniques implemented in this software are covered by pending patent applications:

### Korean Patent Applications (출원 중)

| Series | Domain | Filing Year |
|---|---|---|
| 10-2026-* (32 applications) | AI Execution Control, Runtime Governance, Risk-Dose Accumulation | 2026 |

### Core Patented Techniques

1. **Korean Jamo Decomposition + CJK Canonicalization**  
   Method for detecting prompt injection attacks using Korean character-level decomposition and CJK script normalization.

2. **Session-Level Risk-Dose Accumulation**  
   Stateful temporal risk scoring system that accumulates risk across multiple requests within a session, enabling detection of gradual escalation attacks.

3. **Fail-Closed Bio-Immune Architecture**  
   AI execution control system modeled on biological immune response, with collapse propagation and autonomous recovery.

4. **Chokepoint (길목) Patent Strategy**  
   Architectural method for positioning safety control layers at mandatory execution chokepoints in AI agent pipelines.

### PCT Filing

International patent cooperation treaty (PCT) filing is scheduled for **January 2027**, claiming priority from the Korean applications above.

---

## License vs. Patent Rights

- **Source code** is released under the MIT License (see LICENSE)
- **Patent rights** are retained by the inventor and are **not** transferred by the MIT License
- Using this code in a commercial product requires a separate patent license agreement for the patented techniques listed above

---

## Commercial Licensing

For commercial licensing inquiries, patent licensing, or acquisition discussions:

- GitHub Issues (preferred for initial contact)
- LinkedIn: MinGi Kim

---

*This notice is provided for informational purposes. Consult a patent attorney for legal advice regarding patent rights and licensing obligations.*
